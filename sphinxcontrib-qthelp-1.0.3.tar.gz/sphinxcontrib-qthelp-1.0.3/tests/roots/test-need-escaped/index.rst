.. Sphinx Tests documentation master file, created by sphinx-quickstart on Wed Jun  4 23:49:58 2008.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Sphinx Tests's documentation!
========================================

Contents:

.. toctree::
   :maxdepth: 2
   :numbered:
   :caption: Table of Contents
   :name: mastertoc

   foo
   bar
   http://sphinx-doc.org/
   baz
   qux

.. index::
   pair: "subsection"; <subsection>
   single: & (ampersand)
   single: < (less)
   single: > (greater)
   single: Sphinx (document generator)
   single: keyword1 (class in ID)
   single: keyword2 (foo bar baz)

----------
subsection
----------

subsubsection
-------------
