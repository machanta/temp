project = 'need <b>"escaped"</b> project'
smartquotes = False
