test-htmlhelp-domain_indices
----------------------------

section
~~~~~~~

.. py:module:: sphinx

subsection
^^^^^^^^^^

.. toctree::

   foo
   baz
