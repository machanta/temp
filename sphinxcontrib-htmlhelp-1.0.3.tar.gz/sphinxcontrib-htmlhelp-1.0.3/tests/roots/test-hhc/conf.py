html_short_title = "Sphinx's documentation"
