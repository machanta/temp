foo
---

.. toctree::

   bar
