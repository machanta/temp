/*
 * Some Number Test
 */

int i = 24241424;
float f1 = 342423423.24234;
float f2 = 25235235.;
float f3 = .234234;
float f4 = 234243e+34343;
float f5 = 24234e-234;
int o = 0234;
int h = 0x2342;
