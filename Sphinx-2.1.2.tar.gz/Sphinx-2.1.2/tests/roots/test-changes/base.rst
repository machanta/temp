Version markup
--------------

.. versionadded:: 0.6
   Some funny **stuff**.

.. versionchanged:: 0.6
   Even more funny stuff.

.. deprecated:: 0.6
   Boring stuff.

.. versionadded:: 1.2

   First paragraph of versionadded.

.. versionchanged:: 1.2
   First paragraph of versionchanged.

   Second paragraph of versionchanged.
