# Literally included file using Python highlighting

foo = "Including Unicode characters: üöä"

class Foo:
    pass

class Bar:
    def baz():
        pass

# comment after Bar class definition
def bar(): pass

def block_start_with_comment():
    # Comment
    return 1

def block_start_with_blank():

    return 1


class Qux:
	def quux(self):
		pass
