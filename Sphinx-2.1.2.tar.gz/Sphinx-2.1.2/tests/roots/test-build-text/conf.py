source_suffix = '.txt'
exclude_patterns = ['_build']
