// +build windows

package collector

import (
	"encoding/json"
	"errors"
	"fmt"

	"github.com/StackExchange/wmi"
)

func init() {
	Factories["system"] = NewSystemCollector
}

// A SystemCollector is a Prometheus collector for WMI metrics
type SystemCollector struct {
	Type                      string
	ContextSwitchesPersec     uint32
	ExceptionDispatchesPersec uint32

	ProcessorQueueLength uint32
	SystemCallsPersec    uint32
	SystemUpTime         uint64
	Threads              uint32
}

// NewSystemCollector ...
func NewSystemCollector() (Collector, error) {
	const subsystem = "system"

	return &SystemCollector{
		Type:                      "system",
		ContextSwitchesPersec:     0,
		ExceptionDispatchesPersec: 0,

		ProcessorQueueLength: 0,
		SystemCallsPersec:    0,
		SystemUpTime:         0,
		Threads:              0,
	}, nil
}

// Collect sends the metric values for each metric
// to the provided prometheus Metric channel.
func (c *SystemCollector) Collect(ch chan<- string) error {
	if desc, err := c.collect(ch); err != nil {
		fmt.Println("failed collecting system metrics:", desc, err)
		return err
	}
	return nil
}

// Win32_PerfRawData_PerfOS_System docs:
// - https://web.archive.org/web/20050830140516/http://msdn.microsoft.com/library/en-us/wmisdk/wmi/win32_perfrawdata_perfos_system.asp
type Win32_PerfFormattedData_PerfOS_System struct {
	ContextSwitchesPersec     uint32
	ExceptionDispatchesPersec uint32

	ProcessorQueueLength uint32
	SystemCallsPersec    uint32
	SystemUpTime         uint64
	Threads              uint32
	//Timestamp_Object     uint64
}

func (c *SystemCollector) collect(ch chan<- string) (string, error) {
	var dst []Win32_PerfFormattedData_PerfOS_System
	q := queryAll(&dst)
	if err := wmi.Query(q, &dst); err != nil {
		return "", err
	}
	if len(dst) == 0 {
		return "", errors.New("WMI query returned empty result set")
	}

	sys1 := SystemCollector{
		Type:                      "system",
		ContextSwitchesPersec:     dst[0].ContextSwitchesPersec,
		ExceptionDispatchesPersec: dst[0].ExceptionDispatchesPersec,

		ProcessorQueueLength: dst[0].ProcessorQueueLength,
		SystemCallsPersec:    dst[0].SystemCallsPersec,
		SystemUpTime:         dst[0].SystemUpTime,
		Threads:              dst[0].Threads,
	}
	/*ch <- prometheus.MustNewConstMetric(
		c.ContextSwitchesTotal,
		prometheus.CounterValue,
		float64(dst[0].ContextSwitchesPersec),
	)
	ch <- prometheus.MustNewConstMetric(
		c.ExceptionDispatchesTotal,
		prometheus.CounterValue,
		float64(dst[0].ExceptionDispatchesPersec),
	)
	ch <- prometheus.MustNewConstMetric(
		c.ProcessorQueueLength,
		prometheus.GaugeValue,
		float64(dst[0].ProcessorQueueLength),
	)
	ch <- prometheus.MustNewConstMetric(
		c.SystemCallsTotal,
		prometheus.CounterValue,
		float64(dst[0].SystemCallsPersec),
	)
	ch <- prometheus.MustNewConstMetric(
		c.SystemUpTime,
		prometheus.GaugeValue,
		// convert from Windows timestamp (1 jan 1601) to unix timestamp (1 jan 1970)
		float64(dst[0].SystemUpTime-116444736000000000)/float64(dst[0].Frequency_Object),
	)
	ch <- prometheus.MustNewConstMetric(
		c.Threads,
		prometheus.GaugeValue,
		float64(dst[0].Threads),
	)
	*/

	var jsonData []byte
	jsonData, err := json.Marshal(sys1)
	if err != nil {
		fmt.Println(err)
	}
	ch <- string(jsonData)
	//	fmt.Println(string(jsonData))
	return "", nil

}
