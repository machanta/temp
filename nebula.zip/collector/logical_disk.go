// +build windows

package collector

import (
	"encoding/json"
	"fmt"
	"regexp"

	"github.com/StackExchange/wmi"

	"gopkg.in/alecthomas/kingpin.v2"
)

func init() {
	Factories["logical_disk"] = NewLogicalDiskCollector
}

var (
	volumeWhitelist = kingpin.Flag(
		"collector.logical_disk.volume-whitelist",
		"Regexp of volumes to whitelist. Volume name must both match whitelist and not match blacklist to be included.",
	).Default(".+").String()
	volumeBlacklist = kingpin.Flag(
		"collector.logical_disk.volume-blacklist",
		"Regexp of volumes to blacklist. Volume name must both match whitelist and not match blacklist to be included.",
	).Default("").String()
)

// A LogicalDiskCollector is a Prometheus collector for WMI Win32_PerfRawData_PerfDisk_LogicalDisk metrics
type LogicalDiskCollector struct {
	Name                   string
	CurrentDiskQueueLength uint32
	DiskReadBytesPerSec    uint64
	DiskReadsPerSec        uint32
	DiskWriteBytesPerSec   uint64
	DiskWritesPerSec       uint32
	PercentDiskReadTime    uint64
	PercentDiskWriteTime   uint64
	PercentFreeSpace       uint32
	PercentFreeSpace_Base  uint32
	PercentIdleTime        uint64
	SplitIOPerSec          uint32

	volumeWhitelistPattern *regexp.Regexp
	volumeBlacklistPattern *regexp.Regexp
}

// NewLogicalDiskCollector ...
func NewLogicalDiskCollector() (Collector, error) {
	const subsystem = "logical_disk"

	return &LogicalDiskCollector{
		Name:                   "",
		CurrentDiskQueueLength: 0,
		DiskReadBytesPerSec:    0,
		DiskReadsPerSec:        0,
		DiskWriteBytesPerSec:   0,
		DiskWritesPerSec:       0,
		PercentDiskReadTime:    0,
		PercentDiskWriteTime:   0,
		PercentFreeSpace:       0,
		PercentFreeSpace_Base:  0,
		PercentIdleTime:        0,
		SplitIOPerSec:          0,

		volumeWhitelistPattern: regexp.MustCompile(fmt.Sprintf("^(?:%s)$", *volumeWhitelist)),
		volumeBlacklistPattern: regexp.MustCompile(fmt.Sprintf("^(?:%s)$", *volumeBlacklist)),
	}, nil
}

// Collect sends the metric values for each metric
// to the provided prometheus Metric channel.
func (c *LogicalDiskCollector) Collect(ch chan<- string) error {
	if desc, err := c.collect(ch); err != nil {
		fmt.Println("failed collecting logical_disk metrics:", desc, err)
		return err
	}
	return nil
}

// Win32_PerfRawData_PerfDisk_LogicalDisk docs:
// - https://msdn.microsoft.com/en-us/windows/hardware/aa394307(v=vs.71) - Win32_PerfRawData_PerfDisk_LogicalDisk class
// - https://msdn.microsoft.com/en-us/library/ms803973.aspx - LogicalDisk object reference
type Win32_PerfFormattedData_PerfDisk_LogicalDisk struct {
	Name                   string
	CurrentDiskQueueLength uint32
	DiskReadBytesPerSec    uint64
	DiskReadsPerSec        uint32
	DiskWriteBytesPerSec   uint64
	DiskWritesPerSec       uint32
	PercentDiskReadTime    uint64
	PercentDiskWriteTime   uint64
	PercentFreeSpace       uint32
	PercentFreeSpace_Base  uint32
	PercentIdleTime        uint64
	SplitIOPerSec          uint32
}
type DISKS struct {
	Type string

	List []LogicalDiskCollector
}

func (c *LogicalDiskCollector) collect(ch chan<- string) (string, error) {
	var dst []Win32_PerfFormattedData_PerfDisk_LogicalDisk
	q := queryAll(&dst)
	if err := wmi.Query(q, &dst); err != nil {
		return "", err
	}

	DiskList := make([]LogicalDiskCollector, 0)

	for _, volume := range dst {
		if volume.Name == "_Total" || c.volumeBlacklistPattern.MatchString(volume.Name) {
			//||
			//!c.volumeWhitelistPattern.MatchString(volume.Name)

			continue
		}

		diskC := LogicalDiskCollector{
			Name:                   volume.Name,
			CurrentDiskQueueLength: volume.CurrentDiskQueueLength,
			DiskReadBytesPerSec:    volume.DiskReadBytesPerSec,
			DiskReadsPerSec:        volume.DiskReadsPerSec,
			DiskWriteBytesPerSec:   volume.DiskWriteBytesPerSec,
			DiskWritesPerSec:       volume.DiskWritesPerSec,
			PercentDiskReadTime:    volume.PercentDiskReadTime,
			PercentDiskWriteTime:   volume.PercentDiskWriteTime,
			PercentFreeSpace:       volume.PercentFreeSpace,
			PercentFreeSpace_Base:  volume.PercentFreeSpace_Base,
			PercentIdleTime:        volume.PercentIdleTime,
			SplitIOPerSec:          volume.SplitIOPerSec,

			volumeWhitelistPattern: regexp.MustCompile(fmt.Sprintf("^(?:%s)$", *volumeWhitelist)),
			volumeBlacklistPattern: regexp.MustCompile(fmt.Sprintf("^(?:%s)$", *volumeBlacklist)),
		}

		DiskList = append(DiskList, diskC)
		/*	ch <- prometheus.MustNewConstMetric(
				c.RequestsQueued,
				prometheus.GaugeValue,
				float64(volume.CurrentDiskQueueLength),
				volume.Name,
			)

			ch <- prometheus.MustNewConstMetric(
				c.ReadBytesTotal,
				prometheus.CounterValue,
				float64(volume.DiskReadBytesPerSec),
				volume.Name,
			)

			ch <- prometheus.MustNewConstMetric(
				c.ReadsTotal,
				prometheus.CounterValue,
				float64(volume.DiskReadsPerSec),
				volume.Name,
			)

			ch <- prometheus.MustNewConstMetric(
				c.WriteBytesTotal,
				prometheus.CounterValue,
				float64(volume.DiskWriteBytesPerSec),
				volume.Name,
			)

			ch <- prometheus.MustNewConstMetric(
				c.WritesTotal,
				prometheus.CounterValue,
				float64(volume.DiskWritesPerSec),
				volume.Name,
			)

			ch <- prometheus.MustNewConstMetric(
				c.ReadTime,
				prometheus.CounterValue,
				float64(volume.PercentDiskReadTime)*ticksToSecondsScaleFactor,
				volume.Name,
			)

			ch <- prometheus.MustNewConstMetric(
				c.WriteTime,
				prometheus.CounterValue,
				float64(volume.PercentDiskWriteTime)*ticksToSecondsScaleFactor,
				volume.Name,
			)

			ch <- prometheus.MustNewConstMetric(
				c.FreeSpace,
				prometheus.GaugeValue,
				float64(volume.PercentFreeSpace)*1024*1024,
				volume.Name,
			)

			ch <- prometheus.MustNewConstMetric(
				c.TotalSpace,
				prometheus.GaugeValue,
				float64(volume.PercentFreeSpace_Base)*1024*1024,
				volume.Name,
			)

			ch <- prometheus.MustNewConstMetric(
				c.IdleTime,
				prometheus.CounterValue,
				float64(volume.PercentIdleTime)*ticksToSecondsScaleFactor,
				volume.Name,
			)

			ch <- prometheus.MustNewConstMetric(
				c.SplitIOs,
				prometheus.CounterValue,
				float64(volume.SplitIOPerSec),
				volume.Name,
			) */
	}

	dlist := DISKS{Type: "disk", List: DiskList}
	var jsonData []byte
	jsonData, err := json.Marshal(dlist)
	if err != nil {
		fmt.Println(err)
	}

	//fmt.Println(string(jsonData))
	ch <- string(jsonData)
	return "", nil

}
