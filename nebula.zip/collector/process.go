// +build windows

package collector

import (
	"encoding/json"
	"fmt"
	"sort"
	"strconv"
	"strings"

	"github.com/StackExchange/wmi"
	//	"github.com/prometheus/client_golang/prometheus"
	//	"github.com/prometheus/common/log"
	//	"gopkg.in/alecthomas/kingpin.v2"
)

func init() {
	Factories["process"] = NewProcessCollector
}

var (
	processWhereClause = ""
)

// A ProcessCollector is a Prometheus collector for WMI Win32_PerfRawData_PerfProc_Process metrics
type ProcessCollector struct {
	ProcessName           string
	pid                   string
	cpid                  string
	StartTime             float64
	CPUTimeTotalPriv      float64
	CPUTimeTotalUser      float64
	CPUTimeTotalProcessor float64
	HandleCount           float64
	IOBytesTotal          float64
	IOOperationsTotal     float64
	PageFaultsTotal       float64
	PageFileBytes         float64
	PoolBytes             float64
	PriorityBase          float64
	PrivateBytes          float64
	ThreadCount           float64
	VirtualBytes          float64
	WorkingSet            float64
	Type                  string
	queryWhereClause      string
}

// NewProcessCollector ...
func NewProcessCollector() (Collector, error) {
	const subsystem = "process"

	/*	if *processWhereClause == "" {
			loglog.Warn("No where-clause specified for process collector. This will generate a very large number of metrics!")
		}
	*/
	return &ProcessCollector{
		ProcessName:       "",
		StartTime:         0.0,
		CPUTimeTotalPriv:  0.0,
		CPUTimeTotalUser:  0.0,
		HandleCount:       0.0,
		IOBytesTotal:      0.0,
		IOOperationsTotal: 0.0,
		PageFaultsTotal:   0.0,
		PageFileBytes:     0.0,
		PoolBytes:         0.0,
		PriorityBase:      0.0,
		PrivateBytes:      0.0,
		ThreadCount:       0.0,
		VirtualBytes:      0.0,
		WorkingSet:        0.0,
		queryWhereClause:  "",
	}, nil
}

// Collect sends the metric values for each metric
// to the provided prometheus Metric channel.
func (c *ProcessCollector) Collect(ch chan<- string) error {
	if desc, err := c.collect(ch); err != nil {
		fmt.Println("failed collecting process metrics:", desc, err)
		return err
	}
	return nil
}

// Win32_PerfRawData_PerfProc_Process docs:
// - https://msdn.microsoft.com/en-us/library/aa394323(v=vs.85).aspx
/*type Win32_PerfRawData_PerfProc_Process struct {
	Name                    string
	CreatingProcessID       uint32
	ElapsedTime             uint64
	Frequency_Object        uint64
	HandleCount             uint32
	IDProcess               uint32
	IODataBytesPersec       uint64
	IODataOperationsPersec  uint64
	IOOtherBytesPersec      uint64
	IOOtherOperationsPersec uint64
	IOReadBytesPersec       uint64
	IOReadOperationsPersec  uint64
	IOWriteBytesPersec      uint64
	IOWriteOperationsPersec uint64
	PageFaultsPersec        uint32
	PageFileBytes           uint64
	PageFileBytesPeak       uint64
	PercentPrivilegedTime   uint64
	PercentProcessorTime    uint64
	PercentUserTime         uint64
	PoolNonpagedBytes       uint32
	PoolPagedBytes          uint32
	PriorityBase            uint32
	PrivateBytes            uint64
	ThreadCount             uint32
	Timestamp_Object        uint64
	VirtualBytes            uint64
	VirtualBytesPeak        uint64
	WorkingSet              uint64
	WorkingSetPeak          uint64
	WorkingSetPrivate       uint64
}

*/
type Win32_PerfFormattedData_PerfProc_Process struct {
	Name              string
	CreatingProcessID uint32
	//	Description             string
	ElapsedTime uint64
	//Frequency_Object uint64
	//Frequency_PerfTime      uint64
	//Frequency_Sys100NS      uint64
	HandleCount             uint32
	IDProcess               uint32
	IODataBytesPerSec       uint64
	IODataOperationsPerSec  uint64
	IOOtherBytesPerSec      uint64
	IOOtherOperationsPerSec uint64
	IOReadBytesPerSec       uint64
	IOReadOperationsPerSec  uint64
	IOWriteBytesPerSec      uint64
	IOWriteOperationsPerSec uint64
	//Name                    string
	PageFaultsPerSec      uint32
	PageFileBytes         uint64
	PageFileBytesPeak     uint64
	PercentPrivilegedTime uint64
	PercentProcessorTime  uint64
	PercentUserTime       uint64
	PoolNonpagedBytes     uint32
	PoolPagedBytes        uint32
	PriorityBase          uint32
	PrivateBytes          uint64
	ThreadCount           uint32
	//	Timestamp_Object      uint64
	//	Timestamp_PerfTime    uint64
	//	Timestamp_Sys100NS    uint64
	VirtualBytes     uint64
	VirtualBytesPeak uint64
	WorkingSet       uint64
	WorkingSetPeak   uint64
}
type WorkerProcess struct {
	AppPoolName string
	ProcessId   uint32
}

type Processes struct {
	Type string
	List []ProcessCollector
}

func (c *ProcessCollector) collect(ch chan<- string) (string, error) {
	//var dst []Win32_PerfRawData_PerfProc_Process

	var dst []Win32_PerfFormattedData_PerfProc_Process
	q := queryAllWhere(&dst, c.queryWhereClause)
	if err := wmi.Query(q, &dst); err != nil {
		return "", err
	}

	var dst_wp []WorkerProcess
	q_wp := queryAll(&dst_wp)
	if err := wmi.QueryNamespace(q_wp, &dst_wp, "root\\WebAdministration"); err != nil {
		//	fmt.Println("Could not query WebAdministration namespace for IIS worker processes: %v. Skipping", err)
	}

	ProcessList := make([]ProcessCollector, 0)

	for _, process := range dst {

		if process.Name == "_Total" {
			continue
		}
		// Duplicate processes are suffixed # and an index number. Remove those.
		processName := strings.Split(process.Name, "#")[0]
		pid := strconv.FormatUint(uint64(process.IDProcess), 10)
		cpid := strconv.FormatUint(uint64(process.CreatingProcessID), 10)

		for _, wp := range dst_wp {
			if wp.ProcessId == process.IDProcess {
				processName = strings.Join([]string{processName, wp.AppPoolName}, "_")
				break
			}
		}
		cl := ProcessCollector{
			Type:        "process",
			ProcessName: processName,
			pid:         pid,
			cpid:        cpid,
			//StartTime:        float64(process.ElapsedTime-116444736000000000) / float64(process.Frequency_Object),
			HandleCount:      float64(process.HandleCount),
			CPUTimeTotalPriv: float64(process.PercentPrivilegedTime) * ticksToSecondsScaleFactor,
			CPUTimeTotalUser: float64(process.PercentUserTime) * ticksToSecondsScaleFactor,

			CPUTimeTotalProcessor: float64(process.PercentProcessorTime),
			ThreadCount:           float64(process.ThreadCount),
			WorkingSet:            float64(process.WorkingSet),
			VirtualBytes:          float64(process.VirtualBytes),
		}

		ProcessList = append(ProcessList, cl)
		//fmt.Println(process.PercentProcessorTime)
		/*c.Type = "process"
		c.ProcessName = processName
		c.pid = pid
		c.cpid = cpid
		c.StartTime = float64(process.ElapsedTime-116444736000000000) / float64(process.Frequency_Object)
		c.HandleCount = float64(process.HandleCount)
		c.CPUTimeTotalPriv = float64(process.PercentPrivilegedTime) * ticksToSecondsScaleFactor
		c.CPUTimeTotalUser = float64(process.PercentUserTime) * ticksToSecondsScaleFactor
		c.ThreadCount = float64(process.ThreadCount)
		c.WorkingSet = float64(process.WorkingSet)
		c.VirtualBytes = float64(process.VirtualBytes) */

		//fmt.Println(string(jsonData))
		//	c.IOOtherBytesPersec = float64(process.IOOtherBytesPersec)
		//	c.IOReadBytesPersec =  float64(process.IOReadBytesPersec)

		/*ch <- prometheus.MustNewConstMetric(
			c.StartTime,
			prometheus.GaugeValue,
			// convert from Windows timestamp (1 jan 1601) to unix timestamp (1 jan 1970)
			float64(process.ElapsedTime-116444736000000000)/float64(process.Frequency_Object),
			processName,
			pid,
			cpid,
		)

		ch <- prometheus.MustNewConstMetric(
			c.HandleCount,
			prometheus.GaugeValue,
			float64(process.HandleCount),
			processName,
			pid,
			cpid,
		)

		ch <- prometheus.MustNewConstMetric(
			c.CPUTimeTotal,
			prometheus.CounterValue,
			float64(process.PercentPrivilegedTime)*ticksToSecondsScaleFactor,
			processName,
			pid,
			cpid,
			"privileged",
		)

		ch <- prometheus.MustNewConstMetric(
			c.CPUTimeTotal,
			prometheus.CounterValue,
			float64(process.PercentUserTime)*ticksToSecondsScaleFactor,
			processName,
			pid,
			cpid,
			"user",
		)

		ch <- prometheus.MustNewConstMetric(
			c.IOBytesTotal,
			prometheus.CounterValue,
			float64(process.IOOtherBytesPersec),
			processName,
			pid,
			cpid,
			"other",
		)

		ch <- prometheus.MustNewConstMetric(
			c.IOOperationsTotal,
			prometheus.CounterValue,
			float64(process.IOOtherOperationsPersec),
			processName,
			pid,
			cpid,
			"other",
		)

		ch <- prometheus.MustNewConstMetric(
			c.IOBytesTotal,
			prometheus.CounterValue,
			float64(process.IOReadBytesPersec),
			processName,
			pid,
			cpid,
			"read",
		)

		ch <- prometheus.MustNewConstMetric(
			c.IOOperationsTotal,
			prometheus.CounterValue,
			float64(process.IOReadOperationsPersec),
			processName,
			pid,
			cpid,
			"read",
		)

		ch <- prometheus.MustNewConstMetric(
			c.IOBytesTotal,
			prometheus.CounterValue,
			float64(process.IOWriteBytesPersec),
			processName,
			pid,
			cpid,
			"write",
		)

		ch <- prometheus.MustNewConstMetric(
			c.IOOperationsTotal,
			prometheus.CounterValue,
			float64(process.IOWriteOperationsPersec),
			processName,
			pid,
			cpid,
			"write",
		)

		ch <- prometheus.MustNewConstMetric(
			c.PageFaultsTotal,
			prometheus.CounterValue,
			float64(process.PageFaultsPersec),
			processName,
			pid,
			cpid,
		)

		ch <- prometheus.MustNewConstMetric(
			c.PageFileBytes,
			prometheus.GaugeValue,
			float64(process.PageFileBytes),
			processName,
			pid,
			cpid,
		)

		ch <- prometheus.MustNewConstMetric(
			c.PoolBytes,
			prometheus.GaugeValue,
			float64(process.PoolNonpagedBytes),
			processName,
			pid,
			cpid,
			"nonpaged",
		)

		ch <- prometheus.MustNewConstMetric(
			c.PoolBytes,
			prometheus.GaugeValue,
			float64(process.PoolPagedBytes),
			processName,
			pid,
			cpid,
			"paged",
		)

		ch <- prometheus.MustNewConstMetric(
			c.PriorityBase,
			prometheus.GaugeValue,
			float64(process.PriorityBase),
			processName,
			pid,
			cpid,
		)

		ch <- prometheus.MustNewConstMetric(
			c.PrivateBytes,
			prometheus.GaugeValue,
			float64(process.PrivateBytes),
			processName,
			pid,
			cpid,
		)

		ch <- prometheus.MustNewConstMetric(
			c.ThreadCount,
			prometheus.GaugeValue,
			float64(process.ThreadCount),
			processName,
			pid,
			cpid,
		)

		ch <- prometheus.MustNewConstMetric(
			c.VirtualBytes,
			prometheus.GaugeValue,
			float64(process.VirtualBytes),
			processName,
			pid,
			cpid,
		)

		ch <- prometheus.MustNewConstMetric(
			c.WorkingSet,
			prometheus.GaugeValue,
			float64(process.WorkingSet),
			processName,
			pid,
			cpid,
		)
		*/
	}

	sort.Slice(ProcessList, func(i, j int) bool {
		return ProcessList[i].CPUTimeTotalProcessor > ProcessList[j].CPUTimeTotalProcessor

	})

	ProcessList = ProcessList[:10]
	plist := Processes{Type: "process", List: ProcessList}
	var jsonData []byte
	jsonData, err := json.Marshal(plist)
	if err != nil {
		fmt.Println(err)
	}
	ch <- string(jsonData)

	return "", nil
}
