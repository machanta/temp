// +build windows

package collector

import (
	"encoding/json"
	"fmt"
	"regexp"

	"github.com/StackExchange/wmi"

	"gopkg.in/alecthomas/kingpin.v2"
)

func init() {
	Factories["net"] = NewNetworkCollector
}

var (
	nicWhitelist = kingpin.Flag(
		"collector.net.nic-whitelist",
		"Regexp of NIC:s to whitelist. NIC name must both match whitelist and not match blacklist to be included.",
	).Default(".+").String()
	nicBlacklist = kingpin.Flag(
		"collector.net.nic-blacklist",
		"Regexp of NIC:s to blacklist. NIC name must both match whitelist and not match blacklist to be included.",
	).Default("").String()
	nicNameToUnderscore = regexp.MustCompile("[^a-zA-Z0-9]")
)

// A NetworkCollector is a Prometheus collector for WMI Win32_PerfRawData_Tcpip_NetworkInterface metrics
type NetworkCollector struct {
	NickName                 string
	BytesReceivedTotal       uint64
	BytesSentTotal           uint64
	BytesTotal               uint64
	PacketsOutboundDiscarded uint64
	PacketsOutboundErrors    uint64
	PacketsTotal             uint64
	PacketsReceivedDiscarded uint64
	PacketsReceivedErrors    uint64
	PacketsReceivedTotal     uint64
	PacketsReceivedUnknown   uint64
	PacketsSentTotal         uint64
	CurrentBandwidth         uint64

	nicWhitelistPattern *regexp.Regexp
	nicBlacklistPattern *regexp.Regexp
}

// NewNetworkCollector ...
func NewNetworkCollector() (Collector, error) {
	const subsystem = "net"

	return &NetworkCollector{
		NickName:                 "",
		BytesReceivedTotal:       0,
		BytesSentTotal:           0,
		BytesTotal:               0,
		PacketsOutboundDiscarded: 0,
		PacketsOutboundErrors:    0,
		PacketsTotal:             0,
		PacketsReceivedDiscarded: 0,
		PacketsReceivedErrors:    0,
		PacketsReceivedTotal:     0,
		PacketsReceivedUnknown:   0,
		PacketsSentTotal:         0,
		CurrentBandwidth:         0,

		nicWhitelistPattern: regexp.MustCompile(fmt.Sprintf("^(?:%s)$", *nicWhitelist)),
		nicBlacklistPattern: regexp.MustCompile(fmt.Sprintf("^(?:%s)$", *nicBlacklist)),
	}, nil
}

// Collect sends the metric values for each metric
// to the provided prometheus Metric channel.
func (c *NetworkCollector) Collect(ch chan<- string) error {
	if desc, err := c.collect(ch); err != nil {
		fmt.Println("failed collecting net metrics:", desc, err)
		return err
	}
	return nil
}

// mangleNetworkName mangles Network Adapter name (non-alphanumeric to _)
// that is used in Win32_PerfRawData_Tcpip_NetworkInterface.
func mangleNetworkName(name string) string {
	return nicNameToUnderscore.ReplaceAllString(name, "_")
}

// Win32_PerfRawData_Tcpip_NetworkInterface docs:
// - https://technet.microsoft.com/en-us/security/aa394340(v=vs.80)
type Win32_PerfFormattedData_Tcpip_NetworkInterface struct {
	BytesReceivedPerSec      uint64
	BytesSentPerSec          uint64
	BytesTotalPerSec         uint64
	Name                     string
	PacketsOutboundDiscarded uint64
	PacketsOutboundErrors    uint64
	PacketsPerSec            uint64
	PacketsReceivedDiscarded uint64
	PacketsReceivedErrors    uint64
	PacketsReceivedPerSec    uint64
	PacketsReceivedUnknown   uint64
	PacketsSentPerSec        uint64
	CurrentBandwidth         uint64
}

type NETS struct {
	Type string

	List []NetworkCollector
}

func (c *NetworkCollector) collect(ch chan<- string) (string, error) {
	var dst []Win32_PerfFormattedData_Tcpip_NetworkInterface

	q := queryAll(&dst)
	if err := wmi.Query(q, &dst); err != nil {
		return "", err
	}
	NetworkList := make([]NetworkCollector, 0)
	for _, nic := range dst {

		//	if c.nicBlacklistPattern.MatchString(nic.Name) ||
		//		!c.nicWhitelistPattern.MatchString(nic.Name) {
		//		continue
		//	}

		name := mangleNetworkName(nic.Name)
		if name == "" {
			continue
		}

		netC := NetworkCollector{
			NickName:                 name,
			BytesReceivedTotal:       nic.BytesReceivedPerSec,
			BytesSentTotal:           nic.BytesSentPerSec,
			BytesTotal:               nic.BytesTotalPerSec,
			PacketsOutboundDiscarded: nic.PacketsOutboundDiscarded,
			PacketsOutboundErrors:    nic.PacketsOutboundErrors,
			PacketsTotal:             nic.PacketsPerSec,
			PacketsReceivedDiscarded: nic.PacketsReceivedDiscarded,
			PacketsReceivedErrors:    nic.PacketsReceivedErrors,
			PacketsReceivedTotal:     nic.PacketsReceivedPerSec,
			PacketsReceivedUnknown:   nic.PacketsReceivedUnknown,
			PacketsSentTotal:         nic.PacketsSentPerSec,
			CurrentBandwidth:         nic.CurrentBandwidth,

			nicWhitelistPattern: regexp.MustCompile(fmt.Sprintf("^(?:%s)$", *nicWhitelist)),
			nicBlacklistPattern: regexp.MustCompile(fmt.Sprintf("^(?:%s)$", *nicBlacklist)),
		}

		NetworkList = append(NetworkList, netC)

		// Counters
		/*	ch <- prometheus.MustNewConstMetric(
				c.BytesReceivedTotal,
				prometheus.CounterValue,
				float64(nic.BytesReceivedPerSec),
				name,
			)
			ch <- prometheus.MustNewConstMetric(
				c.BytesSentTotal,
				prometheus.CounterValue,
				float64(nic.BytesSentPerSec),
				name,
			)
			ch <- prometheus.MustNewConstMetric(
				c.BytesTotal,
				prometheus.CounterValue,
				float64(nic.BytesTotalPerSec),
				name,
			)
			ch <- prometheus.MustNewConstMetric(
				c.PacketsOutboundDiscarded,
				prometheus.CounterValue,
				float64(nic.PacketsOutboundDiscarded),
				name,
			)
			ch <- prometheus.MustNewConstMetric(
				c.PacketsOutboundErrors,
				prometheus.CounterValue,
				float64(nic.PacketsOutboundErrors),
				name,
			)
			ch <- prometheus.MustNewConstMetric(
				c.PacketsTotal,
				prometheus.CounterValue,
				float64(nic.PacketsPerSec),
				name,
			)
			ch <- prometheus.MustNewConstMetric(
				c.PacketsReceivedDiscarded,
				prometheus.CounterValue,
				float64(nic.PacketsReceivedDiscarded),
				name,
			)
			ch <- prometheus.MustNewConstMetric(
				c.PacketsReceivedErrors,
				prometheus.CounterValue,
				float64(nic.PacketsReceivedErrors),
				name,
			)
			ch <- prometheus.MustNewConstMetric(
				c.PacketsReceivedTotal,
				prometheus.CounterValue,
				float64(nic.PacketsReceivedPerSec),
				name,
			)
			ch <- prometheus.MustNewConstMetric(
				c.PacketsReceivedUnknown,
				prometheus.CounterValue,
				float64(nic.PacketsReceivedUnknown),
				name,
			)
			ch <- prometheus.MustNewConstMetric(
				c.PacketsSentTotal,
				prometheus.CounterValue,
				float64(nic.PacketsSentPerSec),
				name,
			)
			ch <- prometheus.MustNewConstMetric(
				c.CurrentBandwidth,
				prometheus.CounterValue,
				float64(nic.CurrentBandwidth),
				name,
			)  */
	}
	nlist := NETS{Type: "network", List: NetworkList}
	var jsonData []byte
	jsonData, err := json.Marshal(nlist)
	if err != nil {
		fmt.Println(err)
	}

	//fmt.Println(string(jsonData))
	ch <- string(jsonData)
	return "", nil
}
