// +build windows

package collector

import (
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"time"

	"github.com/StackExchange/wmi"
	//	"github.com/prometheus/client_golang/prometheus"
	//	"github.com/prometheus/common/log"
)

func init() {
	Factories["os"] = NewOSCollector
}

// A OSCollector is a Prometheus collector for WMI metrics
type OSCollector struct {
	PhysicalMemoryFreeBytes float64
	PagingFreeBytes         float64
	VirtualMemoryFreeBytes  float64
	ProcessesLimit          float64
	ProcessMemoryLimitBytes float64
	Processes               float64
	Users                   float64
	PagingLimitBytes        float64
	VirtualMemoryBytes      float64
	VisibleMemoryBytes      float64
	Time                    float64
	Timezone                string
	Type                    string
}

// NewOSCollector ...
func NewOSCollector() (Collector, error) {
	const subsystem = "os"

	return &OSCollector{
		PagingLimitBytes: 0.0,
		//"OperatingSystem.SizeStoredInPagingFiles",

		PagingFreeBytes: 0.0,
		//	"OperatingSystem.FreeSpaceInPagingFiles",

		PhysicalMemoryFreeBytes: 0.0,
		//"OperatingSystem.FreePhysicalMemory",

		Time: 0.0,
		//"OperatingSystem.LocalDateTime",

		Timezone: "OperatingSystem.LocalDateTime",

		Processes: 0.0,
		//"OperatingSystem.NumberOfProcesses",

		ProcessesLimit: 0.0,
		//"OperatingSystem.MaxNumberOfProcesses",

		ProcessMemoryLimitBytes: 0.0,
		//"OperatingSystem.MaxProcessMemorySize",

		Users: 0.0,
		//"OperatingSystem.NumberOfUsers",

		VirtualMemoryBytes: 0.0,
		//"OperatingSystem.TotalVirtualMemorySize",

		VisibleMemoryBytes: 0.0,
		//"OperatingSystem.TotalVisibleMemorySize",

		VirtualMemoryFreeBytes: 0.0,
		//"OperatingSystem.FreeVirtualMemory",

	}, nil
}

// Collect sends the metric values for each metric
// to the provided prometheus Metric channel.
func (c *OSCollector) Collect(ch chan<- string) error {
	if desc, err := c.collect(ch); err != nil {
		fmt.Println("failed collecting os metrics:", desc, err)
		return err
	}
	return nil
}

// Win32_OperatingSystem docs:
// - https://msdn.microsoft.com/en-us/library/aa394239 - Win32_OperatingSystem class
type Win32_OperatingSystem struct {
	FreePhysicalMemory      uint64
	FreeSpaceInPagingFiles  uint64
	FreeVirtualMemory       uint64
	MaxNumberOfProcesses    uint32
	MaxProcessMemorySize    uint64
	NumberOfProcesses       uint32
	NumberOfUsers           uint32
	SizeStoredInPagingFiles uint64
	TotalVirtualMemorySize  uint64
	TotalVisibleMemorySize  uint64
	LocalDateTime           time.Time
}

func (c *OSCollector) collect(ch chan<- string) (string, error) {
	var dst []Win32_OperatingSystem
	q := queryAll(&dst)
	if err := wmi.Query(q, &dst); err != nil {
		return "", err
	}

	if len(dst) == 0 {
		return "", errors.New("WMI query returned empty result set")
	}

	c.Type = "os"
	c.PhysicalMemoryFreeBytes = float64(dst[0].FreePhysicalMemory * 1024)
	time := dst[0].LocalDateTime
	c.Time = float64(time.Unix())
	timezoneName, _ := time.Zone()
	c.Timezone = timezoneName
	c.PagingFreeBytes = float64(dst[0].FreeSpaceInPagingFiles * 1024)
	c.VirtualMemoryFreeBytes = float64(dst[0].FreeVirtualMemory * 1024)
	c.ProcessesLimit = float64(dst[0].MaxNumberOfProcesses)
	c.ProcessMemoryLimitBytes = float64(dst[0].MaxProcessMemorySize * 1024)
	c.Processes = float64(dst[0].NumberOfProcesses)
	c.Users = float64(dst[0].NumberOfUsers)
	c.PagingLimitBytes = float64(dst[0].SizeStoredInPagingFiles * 1024)
	c.VirtualMemoryBytes = float64(dst[0].TotalVirtualMemorySize * 1024)
	c.VisibleMemoryBytes = float64(dst[0].TotalVisibleMemorySize * 1024)

	var jsonData []byte
	jsonData, err := json.Marshal(c)
	if err != nil {
		log.Println(err)
	}
	ch <- string(jsonData)
	//fmt.Println(string(jsonData))

	//	var out = "{" +  c.PhysicalMemoryFreeBytes + " : " + float64(dst[0].FreePhysicalMemory*1024) +

	/*	ch <- prometheus.MustNewConstMetric(
			c.PhysicalMemoryFreeBytes,
			prometheus.GaugeValue,
			float64(dst[0].FreePhysicalMemory*1024), // KiB -> bytes
		)

		time := dst[0].LocalDateTime

		ch <- prometheus.MustNewConstMetric(
			c.Time,
			prometheus.GaugeValue,
			float64(time.Unix()),
		)

		timezoneName, _ := time.Zone()

		ch <- prometheus.MustNewConstMetric(
			c.Timezone,
			prometheus.GaugeValue,
			1.0,
			timezoneName,
		)

		ch <- prometheus.MustNewConstMetric(
			c.PagingFreeBytes,
			prometheus.GaugeValue,
			float64(dst[0].FreeSpaceInPagingFiles*1024), // KiB -> bytes
		)

		ch <- prometheus.MustNewConstMetric(
			c.VirtualMemoryFreeBytes,
			prometheus.GaugeValue,
			float64(dst[0].FreeVirtualMemory*1024), // KiB -> bytes
		)

		ch <- prometheus.MustNewConstMetric(
			c.ProcessesLimit,
			prometheus.GaugeValue,
			float64(dst[0].MaxNumberOfProcesses),
		)

		ch <- prometheus.MustNewConstMetric(
			c.ProcessMemoryLimitBytes,
			prometheus.GaugeValue,
			float64(dst[0].MaxProcessMemorySize*1024), // KiB -> bytes
		)

		ch <- prometheus.MustNewConstMetric(
			c.Processes,
			prometheus.GaugeValue,
			float64(dst[0].NumberOfProcesses),
		)

		ch <- prometheus.MustNewConstMetric(
			c.Users,
			prometheus.GaugeValue,
			float64(dst[0].NumberOfUsers),
		)

		ch <- prometheus.MustNewConstMetric(
			c.PagingLimitBytes,
			prometheus.GaugeValue,
			float64(dst[0].SizeStoredInPagingFiles*1024), // KiB -> bytes
		)

		ch <- prometheus.MustNewConstMetric(
			c.VirtualMemoryBytes,
			prometheus.GaugeValue,
			float64(dst[0].TotalVirtualMemorySize*1024), // KiB -> bytes
		)

		ch <- prometheus.MustNewConstMetric(
			c.VisibleMemoryBytes,
			prometheus.GaugeValue,
			float64(dst[0].TotalVisibleMemorySize*1024), // KiB -> bytes
		)
	*/
	return "", nil
}
