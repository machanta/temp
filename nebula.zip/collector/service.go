// +build windows

package collector

import (
	"encoding/json"
	"fmt"
	"strings"

	"github.com/StackExchange/wmi"

	"gopkg.in/alecthomas/kingpin.v2"
)

func init() {
	Factories["service"] = NewserviceCollector
}

var (
	serviceWhereClause = kingpin.Flag(
		"collector.service.services-where",
		"WQL 'where' clause to use in WMI metrics query. Limits the response to the services you specify and reduces the size of the response.",
	).Default(" NAME LIKE 'DHCP%'").String()
)

// A serviceCollector is a Prometheus collector for WMI Win32_Service metrics
type serviceCollector struct {
	ServiceName string
	State       string
	StartMode   string
	Status      string

	queryWhereClause string
}

// NewserviceCollector ...
func NewserviceCollector() (Collector, error) {
	const subsystem = "service"

	if *serviceWhereClause == "" {
		fmt.Println("No where-clause specified for service collector. This will generate a very large number of metrics!")
	}

	return &serviceCollector{
		ServiceName: "",
		State:       "The state of the service (State)",

		StartMode: "The start mode of the service (StartMode)",

		Status: "The status of the service (Status)",

		//queryWhereClause: *serviceWhereClause,
		queryWhereClause: " NAME LIKE 'DHCP%'",
	}, nil
}

// Collect sends the metric values for each metric
// to the provided prometheus Metric channel.
func (c *serviceCollector) Collect(ch chan<- string) error {
	if desc, err := c.collect(ch); err != nil {
		fmt.Println("failed collecting service metrics:", desc, err)
		return err
	}
	return nil
}

// Win32_Service docs:
// - https://msdn.microsoft.com/en-us/library/aa394418(v=vs.85).aspx
type Win32_Service struct {
	Name      string
	State     string
	Status    string
	StartMode string
}

var (
	allStates = []string{
		"stopped",
		"start pending",
		"stop pending",
		"running",
		"continue pending",
		"pause pending",
		"paused",
		"unknown",
	}
	allStartModes = []string{
		"boot",
		"system",
		"auto",
		"manual",
		"disabled",
	}
	allStatuses = []string{
		"ok",
		"error",
		"degraded",
		"unknown",
		"pred fail",
		"starting",
		"stopping",
		"service",
		"stressed",
		"nonrecover",
		"no contact",
		"lost comm",
	}
)

type Services struct {
	Type string
	List []serviceCollector
}

func (c *serviceCollector) collect(ch chan<- string) (string, error) {
	var dst []Win32_Service
	q := queryAllWhere(&dst, c.queryWhereClause)
	if err := wmi.Query(q, &dst); err != nil {
		return "", err
	}

	ServiceList := make([]serviceCollector, 0)

	for _, service := range dst {

		s1 := serviceCollector{
			ServiceName: service.Name,
			State:       service.State,
			StartMode:   strings.ToLower(service.StartMode),
			Status:      strings.ToLower(service.Status),
		}

		ServiceList = append(ServiceList, s1)

		/*	for _, state := range allStates {
				isCurrentState := 0.0
				if state == strings.ToLower(service.State) {
					isCurrentState = 1.0
				}
				ch <- prometheus.MustNewConstMetric(
					c.State,
					prometheus.GaugeValue,
					isCurrentState,
					strings.ToLower(service.Name),
					state,
				)
			}

			for _, startMode := range allStartModes {
				isCurrentStartMode := 0.0
				if startMode == strings.ToLower(service.StartMode) {
					isCurrentStartMode = 1.0
				}
				ch <- prometheus.MustNewConstMetric(
					c.StartMode,
					prometheus.GaugeValue,
					isCurrentStartMode,
					strings.ToLower(service.Name),
					startMode,
				)
			}

			for _, status := range allStatuses {
				isCurrentStatus := 0.0
				if status == strings.ToLower(service.Status) {
					isCurrentStatus = 1.0
				}
				ch <- prometheus.MustNewConstMetric(
					c.Status,
					prometheus.GaugeValue,
					isCurrentStatus,
					strings.ToLower(service.Name),
					status,
				)
			} */
	}

	slist := Services{Type: "service", List: ServiceList}
	var jsonData []byte
	jsonData, err := json.Marshal(slist)
	if err != nil {
		fmt.Println(err)
	}
	ch <- string(jsonData)
	return "", nil
}
