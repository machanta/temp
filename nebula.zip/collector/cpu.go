// +build windows

package collector

import (
	"encoding/json"
	"fmt"
	"strconv"
	"strings"

	"github.com/StackExchange/wmi"

	"golang.org/x/sys/windows/registry"
)

func init() {
	Factories["cpu"] = NewCPUCollector
}

//A function to get windows version from registry

func getWindowsVersion() float64 {
	k, err := registry.OpenKey(registry.LOCAL_MACHINE, `SOFTWARE\Microsoft\Windows NT\CurrentVersion`, registry.QUERY_VALUE)
	if err != nil {
		fmt.Println("Couldn't open registry", err)
		return 0
	}
	defer func() {
		err = k.Close()
		if err != nil {
			fmt.Println("Failed to close registry key: %v", err)
		}
	}()

	currentv, _, err := k.GetStringValue("CurrentVersion")
	if err != nil {
		fmt.Println("Couldn't open registry to determine current Windows version:", err)
		return 0
	}

	currentv_flt, err := strconv.ParseFloat(currentv, 64)

	//	fmt.Println("Detected Windows version %f\n", currentv_flt)

	return currentv_flt
}

// A CPUCollector is a Prometheus collector for WMI Win32_PerfRawData_PerfOS_Processor metrics
type CPUCollector struct {
	CpuName string

	PercentIdleTime uint64
	PercentDPCTime  uint64
	PercentC1Time   uint64
	PercentC2Time   uint64
	PercentC3Time   uint64

	PercentInterruptTime  uint64
	PercentPrivilegedTime uint64
	PercentProcessorTime  uint64
	PercentUserTime       uint64
}

// NewCPUCollector constructs a new CPUCollector
func NewCPUCollector() (Collector, error) {
	const subsystem = "cpu"
	return &CPUCollector{
		CpuName: "",

		PercentIdleTime: 0.0,
		PercentDPCTime:  0.0,
		PercentC1Time:   0.0,
		PercentC2Time:   0.0,
		PercentC3Time:   0.0,

		PercentInterruptTime:  0.0,
		PercentPrivilegedTime: 0.0,
		PercentProcessorTime:  0.0,
		PercentUserTime:       0.0,
	}, nil
}

// Collect sends the metric values for each metric
// to the provided prometheus Metric channel.
func (c *CPUCollector) Collect(ch chan<- string) error {
	if desc, err := c.collect(ch); err != nil {
		fmt.Println("failed collecting cpu metrics:", desc, err)
		return err
	}
	return nil
}

// Win32_PerfRawData_PerfOS_Processor docs:
// - https://msdn.microsoft.com/en-us/library/aa394317(v=vs.90).aspx
type Win32_PerfFormattedData_PerfOS_Processor struct {
	Name                  string
	C1TransitionsPersec   uint64
	C2TransitionsPersec   uint64
	C3TransitionsPersec   uint64
	DPCRate               uint32
	DPCsQueuedPersec      uint32
	InterruptsPersec      uint32
	PercentC1Time         uint64
	PercentC2Time         uint64
	PercentC3Time         uint64
	PercentDPCTime        uint64
	PercentIdleTime       uint64
	PercentInterruptTime  uint64
	PercentPrivilegedTime uint64
	PercentProcessorTime  uint64
	PercentUserTime       uint64
}

type Win32_PerfFormattedData_Counters_ProcessorInformation struct {
	Name                        string
	AverageIdleTime             uint64
	C1TransitionsPersec         uint64
	C2TransitionsPersec         uint64
	C3TransitionsPersec         uint64
	ClockInterruptsPersec       uint64
	DPCRate                     uint64
	DPCsQueuedPersec            uint64
	IdleBreakEventsPersec       uint64
	InterruptsPersec            uint64
	ParkingStatus               uint64
	PercentC1Time               uint64
	PercentC2Time               uint64
	PercentC3Time               uint64
	PercentDPCTime              uint64
	PercentIdleTime             uint64
	PercentInterruptTime        uint64
	PercentofMaximumFrequency   uint64
	PercentPerformanceLimit     uint64
	PercentPriorityTime         uint64
	PercentPrivilegedTime       uint64
	PercentPrivilegedUtility    uint64
	PercentProcessorPerformance uint64
	PercentProcessorTime        uint64
	PercentProcessorUtility     uint64
	PercentUserTime             uint64
	PerformanceLimitFlags       uint64
	ProcessorFrequency          uint64
	ProcessorStateFlags         uint64
}

type CPUs struct {
	Type  string
	Total CPUCollector
	List  []CPUCollector
}

func (c *CPUCollector) collect(ch chan<- string) (string, error) {
	version := getWindowsVersion()
	// Windows version by number https://docs.microsoft.com/en-us/windows/desktop/sysinfo/operating-system-version
	// For Windows 2008 or earlier Windows version is 6.0 or lower, so we use Win32_PerfRawData_PerfOS_Processor class
	// For Windows 2008 R2 or later  Windows version is 6.1 or higher, so we use Win32_PerfRawData_Counters_ProcessorInformation
	// Value 6.05 was selected just to split between WIndows versions
	if version > 6.05 {
		var dst []Win32_PerfFormattedData_Counters_ProcessorInformation
		q := queryAll(&dst)
		if err := wmi.Query(q, &dst); err != nil {
			return "", err
		}

		CPUCounterList := make([]CPUCollector, 0)
		var TotalCPU CPUCollector

		for _, data := range dst {
			//	if strings.Contains(data.Name, "_Total") {
			//		continue
			//	}

			var arr []string = strings.Split(data.Name, ",")
			if len(arr) <= 1 {

				continue
			}

			if strings.Contains(data.Name, "_Total") {
				TotalCPU = CPUCollector{
					CpuName: arr[1],

					PercentDPCTime: data.PercentDPCTime,
					PercentC1Time:  data.PercentC1Time,
					PercentC2Time:  data.PercentC2Time,
					PercentC3Time:  data.PercentC3Time,

					PercentIdleTime:       data.PercentIdleTime,
					PercentInterruptTime:  data.PercentInterruptTime,
					PercentPrivilegedTime: data.PercentPrivilegedTime,
					PercentProcessorTime:  data.PercentProcessorTime,
					PercentUserTime:       data.PercentUserTime,
				}
				continue
			}

			cpuC := CPUCollector{
				CpuName: arr[1],

				PercentDPCTime: data.PercentDPCTime,
				PercentC1Time:  data.PercentC1Time,
				PercentC2Time:  data.PercentC2Time,
				PercentC3Time:  data.PercentC3Time,

				PercentIdleTime:       data.PercentIdleTime,
				PercentInterruptTime:  data.PercentInterruptTime,
				PercentPrivilegedTime: data.PercentPrivilegedTime,
				PercentProcessorTime:  data.PercentProcessorTime,
				PercentUserTime:       data.PercentUserTime,
			}

			CPUCounterList = append(CPUCounterList, cpuC)

			//	core := data.Name

			/*	ch <- prometheus.MustNewConstMetric(
					c.ProcessorFrequency,
					prometheus.GaugeValue,
					float64(data.ProcessorFrequency),
					core,
				)
				ch <- prometheus.MustNewConstMetric(
					c.CStateSecondsTotal,
					prometheus.CounterValue,
					float64(data.PercentC1Time)*ticksToSecondsScaleFactor,
					core, "c1",
				)
				ch <- prometheus.MustNewConstMetric(
					c.CStateSecondsTotal,
					prometheus.CounterValue,
					float64(data.PercentC2Time)*ticksToSecondsScaleFactor,
					core, "c2",
				)
				ch <- prometheus.MustNewConstMetric(
					c.CStateSecondsTotal,
					prometheus.CounterValue,
					float64(data.PercentC3Time)*ticksToSecondsScaleFactor,
					core, "c3",
				)

				ch <- prometheus.MustNewConstMetric(
					c.TimeTotal,
					prometheus.CounterValue,
					float64(data.PercentIdleTime)*ticksToSecondsScaleFactor,
					core, "idle",
				)
				ch <- prometheus.MustNewConstMetric(
					c.TimeTotal,
					prometheus.CounterValue,
					float64(data.PercentInterruptTime)*ticksToSecondsScaleFactor,
					core, "interrupt",
				)
				ch <- prometheus.MustNewConstMetric(
					c.TimeTotal,
					prometheus.CounterValue,
					float64(data.PercentDPCTime)*ticksToSecondsScaleFactor,
					core, "dpc",
				)
				ch <- prometheus.MustNewConstMetric(
					c.TimeTotal,
					prometheus.CounterValue,
					float64(data.PercentPrivilegedTime)*ticksToSecondsScaleFactor,
					core, "privileged",
				)
				ch <- prometheus.MustNewConstMetric(
					c.TimeTotal,
					prometheus.CounterValue,
					float64(data.PercentUserTime)*ticksToSecondsScaleFactor,
					core, "user",
				)

				ch <- prometheus.MustNewConstMetric(
					c.InterruptsTotal,
					prometheus.CounterValue,
					float64(data.InterruptsPersec),
					core,
				)
				ch <- prometheus.MustNewConstMetric(
					c.DPCsTotal,
					prometheus.CounterValue,
					float64(data.DPCsQueuedPersec),
					core,
				)
			*/
		}

		clist := CPUs{Type: "cpu", Total: TotalCPU, List: CPUCounterList}
		var jsonData []byte
		jsonData, err := json.Marshal(clist)
		if err != nil {
			fmt.Println(err)
		}

		//fmt.Println(string(jsonData))
		ch <- string(jsonData)

		return "", nil

	}
	/*	var dst []Win32_PerfRawData_PerfOS_Processor
		q := queryAll(&dst)
		if err := wmi.Query(q, &dst); err != nil {
			return nil, err
		}
		for _, data := range dst {
			if strings.Contains(data.Name, "_Total") {
				continue
			}
			core := data.Name
			ch <- prometheus.MustNewConstMetric(
				c.CStateSecondsTotal,
				prometheus.CounterValue,
				float64(data.PercentC1Time)*ticksToSecondsScaleFactor,
				core, "c1",
			)
			ch <- prometheus.MustNewConstMetric(
				c.CStateSecondsTotal,
				prometheus.CounterValue,
				float64(data.PercentC2Time)*ticksToSecondsScaleFactor,
				core, "c2",
			)
			ch <- prometheus.MustNewConstMetric(
				c.CStateSecondsTotal,
				prometheus.CounterValue,
				float64(data.PercentC3Time)*ticksToSecondsScaleFactor,
				core, "c3",
			)
			ch <- prometheus.MustNewConstMetric(
				c.TimeTotal,
				prometheus.CounterValue,
				float64(data.PercentIdleTime)*ticksToSecondsScaleFactor,
				core, "idle",
			)
			ch <- prometheus.MustNewConstMetric(
				c.TimeTotal,
				prometheus.CounterValue,
				float64(data.PercentInterruptTime)*ticksToSecondsScaleFactor,
				core, "interrupt",
			)
			ch <- prometheus.MustNewConstMetric(
				c.TimeTotal,
				prometheus.CounterValue,
				float64(data.PercentDPCTime)*ticksToSecondsScaleFactor,
				core, "dpc",
			)
			ch <- prometheus.MustNewConstMetric(
				c.TimeTotal,
				prometheus.CounterValue,
				float64(data.PercentPrivilegedTime)*ticksToSecondsScaleFactor,
				core, "privileged",
			)
			ch <- prometheus.MustNewConstMetric(
				c.TimeTotal,
				prometheus.CounterValue,
				float64(data.PercentUserTime)*ticksToSecondsScaleFactor,
				core, "user",
			)
			ch <- prometheus.MustNewConstMetric(
				c.InterruptsTotal,
				prometheus.CounterValue,
				float64(data.InterruptsPersec),
				core,
			)
			ch <- prometheus.MustNewConstMetric(
				c.DPCsTotal,
				prometheus.CounterValue,
				float64(data.DPCsQueuedPersec),
				core,
			)
		} */

	return "", nil
}
