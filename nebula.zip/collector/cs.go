// +build windows

package collector

import (
	"encoding/json"
	"errors"
	"fmt"

	"github.com/StackExchange/wmi"
)

func init() {
	Factories["cs"] = NewCSCollector
}

// A CSCollector is a Prometheus collector for WMI metrics
type CSCollector struct {
	Type                string
	PhysicalMemoryBytes uint64
	LogicalProcessors   uint32
}

// NewCSCollector ...
func NewCSCollector() (Collector, error) {
	const subsystem = "cs"

	return &CSCollector{
		Type:                "",
		LogicalProcessors:   0,
		PhysicalMemoryBytes: 0,
	}, nil
}

// Collect sends the metric values for each metric
// to the provided prometheus Metric channel.
func (c *CSCollector) Collect(ch chan<- string) error {
	if desc, err := c.collect(ch); err != nil {
		fmt.Println("failed collecting cs metrics:", desc, err)
		return err
	}
	return nil
}

// Win32_ComputerSystem docs:
// - https://msdn.microsoft.com/en-us/library/aa394102
type Win32_ComputerSystem struct {
	NumberOfLogicalProcessors uint32
	TotalPhysicalMemory       uint64
}

func (c *CSCollector) collect(ch chan<- string) (string, error) {
	var dst []Win32_ComputerSystem
	q := queryAll(&dst)
	if err := wmi.Query(q, &dst); err != nil {
		return "", err
	}
	if len(dst) == 0 {
		return "", errors.New("WMI query returned empty result set")
	}

	cs1 := CSCollector{
		Type:                "cs",
		LogicalProcessors:   dst[0].NumberOfLogicalProcessors,
		PhysicalMemoryBytes: dst[0].TotalPhysicalMemory,
	}
	/*	ch <- prometheus.MustNewConstMetric(
			c.LogicalProcessors,
			prometheus.GaugeValue,
			float64(dst[0].NumberOfLogicalProcessors),
		)

		ch <- prometheus.MustNewConstMetric(
			c.PhysicalMemoryBytes,
			prometheus.GaugeValue,
			float64(dst[0].TotalPhysicalMemory),
		)
	*/

	var jsonData []byte
	jsonData, err := json.Marshal(cs1)
	if err != nil {
		fmt.Println(err)
	}
	ch <- string(jsonData)
	//	fmt.Println(string(jsonData))
	return "", nil
}
