// +build windows

package main

import (
	"crypto/tls"
	"elixr/collector"
	"flag"
	"fmt"
	"net/http"
	"os"
	"os/exec"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/StackExchange/wmi"
	MQTT "github.com/eclipse/paho.mqtt.golang"
	"golang.org/x/sys/windows/svc"
	//	"gopkg.in/alecthomas/kingpin.v2"
)

// WmiCollector implements the prometheus.Collector interface.
type WmiCollector struct {
	collectors map[string]collector.Collector
}

const (
	defaultCollectors            = "cpu,cs,logical_disk,net,os,service,system,textfile,process,memory"
	defaultCollectorsPlaceholder = "[defaults]"
	serviceName                  = "wmi_exporter"
)

var (
	scrapeDurationDesc = "wmi_exporter: Duration of a collection."

	scrapeSuccessDesc = "wmi_exporter: Whether the collector was successful."

	// This can be removed when client_golang exposes this on Windows
	// (See https://github.com/prometheus/client_golang/issues/376)
	startTime     = float64(time.Now().Unix())
	startTimeDesc = "Start time of the process since unix epoch in seconds."
)

// Describe sends all the descriptors of the collectors included to
// the provided channel.
func (coll WmiCollector) Describe(ch chan<- string) {
	ch <- scrapeDurationDesc
	ch <- scrapeSuccessDesc
}

// Collect sends the collected metrics from each of the collectors to
// prometheus. Collect could be called several times concurrently
// and thus its run is protected by a single mutex.
func (coll WmiCollector) Collect(ch chan<- string) {
	wg := sync.WaitGroup{}
	wg.Add(len(coll.collectors))
	for name, c := range coll.collectors {
		go func(name string, c collector.Collector) {
			execute(name, c, ch)
			wg.Done()
		}(name, c)
	}

	//ch <- startTimeDesc

	wg.Wait()
}

func filterAvailableCollectors(collectors string) string {
	var availableCollectors []string
	for _, c := range strings.Split(collectors, ",") {
		_, ok := collector.Factories[c]
		if ok {
			availableCollectors = append(availableCollectors, c)
		}
	}
	return strings.Join(availableCollectors, ",")
}

func execute(name string, c collector.Collector, ch chan<- string) {
	//begin := time.Now()
	err := c.Collect(ch)
	//	duration := time.Since(begin)
	//var success float64

	if err != nil {
		//log.Errorf("collector %s failed after %fs: %s", name, duration.Seconds(), err)
		//success = 0
	} else {
		//log.Debugf("collector %s succeeded after %fs.", name, duration.Seconds())
		//success = 1
	}
	/*	ch <- prometheus.MustNewConstMetric(
			scrapeDurationDesc,
			prometheus.GaugeValue,
			duration.Seconds(),
			name,
		)
		ch <- prometheus.MustNewConstMetric(
			scrapeSuccessDesc,
			prometheus.GaugeValue,
			success,
			name,
		)
	*/
}

func expandEnabledCollectors(enabled string) []string {
	expanded := strings.Replace(enabled, defaultCollectorsPlaceholder, defaultCollectors, -1)
	separated := strings.Split(expanded, ",")
	unique := map[string]bool{}
	for _, s := range separated {
		if s != "" {
			unique[s] = true
		}
	}
	result := make([]string, 0, len(unique))
	for s := range unique {
		result = append(result, s)
	}
	return result
}

func loadCollectors(list string) (map[string]collector.Collector, error) {
	collectors := map[string]collector.Collector{}
	enabled := expandEnabledCollectors(list)

	for _, name := range enabled {
		fn, ok := collector.Factories[name]
		if !ok {
			return nil, fmt.Errorf("collector '%s' not available", name)
		}
		c, err := fn()
		if err != nil {
			return nil, err
		}
		collectors[name] = c
	}
	return collectors, nil
}

func init() {
	//prometheus.MustRegister(version.NewCollector("wmi_exporter"))
}

func initWebServer() {
	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprintf(w, "Nah Nah!")
	})

	http.HandleFunc("/kill", func(w http.ResponseWriter, r *http.Request) {
		c := exec.Command("cmd", "/C", "net", "stop", "dhcpserver")

		if err := c.Run(); err != nil {
			fmt.Println("Error: ", err)
		}
	})

	http.HandleFunc("/start", func(w http.ResponseWriter, r *http.Request) {
		c := exec.Command("cmd", "/C", "net", "start", "dhcpserver")

		if err := c.Run(); err != nil {
			fmt.Println("Error: ", err)
		}
	})

	http.HandleFunc("/stress", func(w http.ResponseWriter, r *http.Request) {
		c := exec.Command("cmd", "/C", "C:\\temp\\stress.exe")

		if err := c.Run(); err != nil {
			fmt.Println("Error: ", err)
		}
	})

	http.HandleFunc("/killstress", func(w http.ResponseWriter, r *http.Request) {
		c := exec.Command("cmd", "/C", "taskkill", "/IM", "stress.exe", "/F")

		if err := c.Run(); err != nil {
			fmt.Println("Error: ", err)
		}
	})
	//fs := http.FileServer(http.Dir("static/"))
	//http.Handle("/static/", http.StripPrefix("/static/", fs))

	http.ListenAndServe(":8090", nil)
}
func initWbem() {
	// This initialization prevents a memory leak on WMF 5+. See
	// https://github.com/martinlindhe/wmi_exporter/issues/77 and linked issues
	// for details.
	fmt.Println("Initializing Elixr Services")
	s, err := wmi.InitializeSWbemServices(wmi.DefaultClient)
	if err != nil {
		fmt.Println(err)
	}
	wmi.DefaultClient.AllowMissingFields = true
	wmi.DefaultClient.SWbemServicesClient = s
}

func main() {

	var enabledCollectors = filterAvailableCollectors(defaultCollectors)

	hostname, _ := os.Hostname()

	server := flag.String("server", "tcp://22.56.45.199:1883", "The full URL of the MQTT server to connect to")
	topic := flag.String("topic", hostname, "Topic to publish the messages on")
	qos := flag.Int("qos", 0, "The QoS to send the messages at")
	retained := flag.Bool("retained", false, "Are the messages sent with the retained flag")
	clientid := flag.String("clientid", hostname+strconv.Itoa(time.Now().Second()), "A clientid for the connection")
	username := flag.String("username", "", "A username to authenticate to the MQTT server")
	password := flag.String("password", "", "Password to match username")
	flag.Parse()

	connOpts := MQTT.NewClientOptions().AddBroker(*server).SetClientID(*clientid).SetCleanSession(true)
	if *username != "" {
		connOpts.SetUsername(*username)
		if *password != "" {
			connOpts.SetPassword(*password)
		}
	}
	tlsConfig := &tls.Config{InsecureSkipVerify: true, ClientAuth: tls.NoClientCert}
	connOpts.SetTLSConfig(tlsConfig)

	client := MQTT.NewClient(connOpts)
	if token := client.Connect(); token.Wait() && token.Error() != nil {
		fmt.Println(token.Error())
		return
	}
	fmt.Printf("Connected to %s\n", *server)

	/*	var (
			listenAddress = kingpin.Flag(
				"telemetry.addr",
				"host:port for WMI exporter.",
			).Default(":9182").String()
			metricsPath = kingpin.Flag(
				"telemetry.path",
				"URL path for surfacing collected metrics.",
			).Default("/metrics").String()
			enabledCollectors = kingpin.Flag(
				"collectors.enabled",
				"Comma-separated list of collectors to use. Use '[defaults]' as a placeholder for all the collectors enabled by default.").
				Default(filterAvailableCollectors(defaultCollectors)).String()
			printCollectors = kingpin.Flag(
				"collectors.print",
				"If true, print available collectors and exit.",
			).Bool()
		)
	*/
	//log.AddFlags(kingpin.CommandLine)
	////kingpin.Version(version.Print("wmi_exporter"))
	//kingpin.HelpFlag.Short('h')
	//kingpin.Parse()

	/*if *printCollectors {
		collectorNames := make(sort.StringSlice, 0, len(collector.Factories))
		for n := range collector.Factories {
			collectorNames = append(collectorNames, n)
		}
		collectorNames.Sort()
		fmt.Printf("Available collectors:\n")
		for _, n := range collectorNames {
			fmt.Printf(" - %s\n", n)
		}
		return
	}
	*/
	initWbem()

	go initWebServer()

	isInteractive, err := svc.IsAnInteractiveSession()
	if err != nil {
		//log.Fatal(err)
		fmt.Println(err)
	}
	if !isInteractive {
		fmt.Println("Not Interactive Process")
	}

	stopCh := make(chan bool)
	/*	if !isInteractive {
			go func() {
				err = svc.Run(serviceName, &wmiExporterService{stopCh: stopCh})
				if err != nil {
					//log.Errorf("Failed to start service: %v", err)
					fmt.Printf("Failed to start service: %v", err)
				}
			}()
		}
	*/
	collectors, err := loadCollectors(enabledCollectors)
	if err != nil {
		//log.Fatalf("Couldn't load collectors: %s", err)
		fmt.Printf("Couldn't load collectors: %s", err)
	}
	messages := make(chan string, 2000)
	//log.Infof("Enabled collectors: %v", strings.Join(keys(collectors), ", "))
	fmt.Printf("Enabled collectors: %v", strings.Join(keys(collectors), ", "))
	nodeCollector := WmiCollector{collectors: collectors}
	//nodeCollector.Collect(messages)

	go func(nodeCollector *WmiCollector) {

		for {
			nodeCollector.Collect(messages)
			time.Sleep(3 * time.Second)
		}
	}(&nodeCollector)

	for {

		select {
		case msg1 := <-messages:
			//fmt.Println("received", msg1)
			client.Publish(*topic, byte(*qos), *retained, msg1)
		default:
			time.Sleep(1 * time.Second)
			//fmt.Println("no msgreceived")
		}

	}
	//prometheus.MustRegister(nodeCollector)

	//http.Handle(*metricsPath, promhttp.Handler())
	//http.HandleFunc("/health", healthCheck)
	//http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
	//	http.Redirect(w, r, *metricsPath, http.StatusMovedPermanently)
	//})

	//.Infoln("Starting WMI exporter", version.Info())
	//log.Infoln("Build context", version.BuildContext())

	//fmt.Printf("Starting WMI exporter")
	//fmt.Printf("Build context")

	/*go func() {
		log.Infoln("Starting server on", *listenAddress)
		log.Fatalf("cannot start WMI exporter: %s", http.ListenAndServe(*listenAddress, nil))
	}()
	*/
	for {
		if <-stopCh {
			fmt.Printf("Shutting down WMI exporter")
			break
		}
	}
}

/*func healthCheck(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	_, err := fmt.Fprintln(w, `{"status":"ok"}`)
	if err != nil {
		log.Debugf("Failed to write to stream: %v", err)
	}
}*/

func keys(m map[string]collector.Collector) []string {
	ret := make([]string, 0, len(m))
	for key := range m {
		ret = append(ret, key)
	}
	return ret
}

/*type wmiExporterService struct {
	stopCh chan<- bool
}

func (s *wmiExporterService) Execute(args []string, r <-chan svc.ChangeRequest, changes chan<- svc.Status) (ssec bool, errno uint32) {
	const cmdsAccepted = svc.AcceptStop | svc.AcceptShutdown
	changes <- svc.Status{State: svc.StartPending}
	changes <- svc.Status{State: svc.Running, Accepts: cmdsAccepted}
loop:
	for {
		select {
		case c := <-r:
			switch c.Cmd {
			case svc.Interrogate:
				changes <- c.CurrentStatus
			case svc.Stop, svc.Shutdown:
				s.stopCh <- true
				break loop
			default:
				log.Error(fmt.Sprintf("unexpected control request #%d", c))
			}
		}
	}
	changes <- svc.Status{State: svc.StopPending}
	return
}
*/
