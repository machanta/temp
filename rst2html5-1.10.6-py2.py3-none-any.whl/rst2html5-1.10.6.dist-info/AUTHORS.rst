
Authors
=======

* André Felipe Dias <andre.dias@pronus.io>
* Axel Haustant <noirbizarre@gmail.com>
* Pavel Puchkin <neoascetic@gmail.com>
* Russ Webber <russ@rw.id.au>
* Lee Loucks <leeloucks@gmail.com>
* Martín Gaitán <gaitan@gmail.com>
* Carmen Bianca Bakker <c.b.bakker@carmenbianca.eu>
