.. _index:

index
=====

.. toctree::

   foo/index
   bar
