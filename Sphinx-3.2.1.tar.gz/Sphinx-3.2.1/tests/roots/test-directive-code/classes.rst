classes
=======

Code blocks
-----------

.. code-block:: ruby
   :class: foo bar
   :name: code_block

       def ruby?
           false
       end


Literal Includes
----------------

.. literalinclude:: literal.inc
   :class: bar baz
   :name: literal_include
