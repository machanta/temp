Code Blocks and Literal Includes with Line Numbers via linenothreshold
======================================================================

.. highlight:: python
   :linenothreshold: 5

.. code-block::

   class Foo:
       pass

   class Bar:
       def baz():
       pass

.. code-block::

   # comment
   value = True

.. literalinclude:: literal.inc

.. literalinclude:: literal-short.inc
